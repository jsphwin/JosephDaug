<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "designs_db";

$con = mysqli_connect($dbhost, $dbuser, $dbpass, $dbname);
